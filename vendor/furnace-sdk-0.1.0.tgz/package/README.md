# @furnace/sdk (TypeScript)

The Furnace executor SDK for TypeScript, one package (`docs/executor-platform/04-low-level-design.md`
§4): the executor half (`ExecutorApp`, `ExecutionContext`, `ExecutionResult`) with its
Generation 1 one-shot host (`dist/src/host.js`) and Generation 2 resident host
(`dist/src/resident.js`, for an `[executors.<name>]` table with `driver = "extension"`), a
conformance CLI (`dist/src/conformance.js`), and a typed client for Furnace's versioned
machine interface over the `furnace` CLI's `--json` and `--jsonl` modes (§8).

This page is the short version. The maintained usage guide (entry points, exits, errors,
and recipes run against the binary) is the Furnace skill's
[`references/sdk-typescript.md`](../../crates/furnace-cli/skills/furnace/references/sdk-typescript.md);
executor definitions, both drivers and the `furnace.executor.v1` wire are in
[`references/executor-platform.md`](../../crates/furnace-cli/skills/furnace/references/executor-platform.md).

## Defining an executor

```ts
import { ExecutorApp, ExecutionResult, type ExecutionContext } from "@furnace/sdk";

export const app = new ExecutorApp();

app.executor("coder", async (ctx: ExecutionContext) => {
  // ctx is the typed context in the wire's own spelling: ctx.work.beads_work_id,
  // ctx.attempt.ordinal, ctx.work.title (string | null: absent text is null, never "").
  return ExecutionResult.success({ summary: `saw ${ctx.work.beads_work_id}` });
});
```

- A bare `async (ctx) => Promise<ExecutionResult>` is the whole API; a synchronous callback
  is accepted too. `defineExecutor(name, cb)` is the standalone form: a declaration value an
  app registers later with `app.register(declaration)`, starting nothing at definition time.
  `ExecutionContext`, its four group types, `ExecutionStatus` and `FailureClass` are
  type-only exports, so import them with `type`.
- Names are exact, case-sensitive protocol identifiers; an empty name, or one with
  surrounding whitespace or a control character, is a `RegistrationError`, a second
  registration of a name a `DuplicateExecutorError`, both at registration time. Two apps in
  one process share nothing (no module-level registry).
- `ExecutionResult.success({ summary?, data? })`,
  `.failure(message, { failure_class?, data? })` (the class is one of `"task"`,
  `"executor"`, `"transient"`, `"configuration"`; it defaults to `"executor"`, and a
  `"task"` failure stays distinct), `.cancelled(message?)`, `.indeterminate(message)`: four
  constructors, four statuses, serialized as the model's exact strings. A failed or
  indeterminate result requires diagnostic text.
- The shipped hosts classify a callback through `runCallback`: a rejection becomes `failure`
  with `failure_class: "executor"`, `callback "<name>" raised <Kind>: <message>` as the
  diagnostic and `{ exception_type, exception_message }` as `data`; a value that is not an
  `ExecutionResult` is `failure` / `"executor"`; an unregistered name is `failure` /
  `"configuration"` from the one-shot host, while the resident host refuses an execute
  naming an executor it does not serve. `app.settle(name, ctx)` is the in-process mapping, with
  `<ErrorName>: <message>` as the diagnostic and an unregistered name rejected with
  `UnknownExecutorError`. Neither guesses that an arbitrary error is transient.
- Validation is the generated contract's: every decode that reaches shape validation uses
  the Smithy-derived validators under `executor-protocol/generated/typescript` (loaded from
  their canonical path, never copied). The SDK's own checks run around them: before, the
  root-object check and then the `context_version` selection (contexts) or the dropping of
  key-present `null` members (results); after, the 32-bit ordinal ceiling (contexts) or the
  failure-class and summary rules (results). `contractProvenance()` reports the model
  digest read from the artifact's manifest.

## Installing

The package declares no `bin` and no `exports` map; `files` ships `dist/src`,
`dist/contract` and `contract/{manifest.json,registry}` and leaves `dist/test` out. The
SDK validates against `executor-protocol/generated/typescript`, a copy of which ships
inside the package: `contract/` is a git-ignored build product
`scripts/sync_sdk_contract.py --write` copies from the committed artifact (the generated
sources, their `manifest.json` naming the model digest and protocol version, and the
registry's durability rule set) and `npm run build` runs first, so `tsc` compiles the
copy to `dist/contract/` beside `dist/src/`. A tarball from `npm pack` therefore validates
when installed anywhere; the committed artifact stays the one source the smithy drift
check convicts, and the loader refuses a copy whose manifest digest disagrees with the
provenance module it carries. An install whose copy is missing throws
`ContractUnavailableError` at its first decode.

```sh
cd sdk/typescript
npm ci
npm run build    # writes dist/, which is not committed
```

A package of your own can then depend on it by path: `npm install <repo>/sdk/typescript`
links it as `node_modules/@furnace/sdk`, which the imports in this README assume. The hosts pick a
definition's app by class identity, so a definition imports the SDK from the same
`dist/src` whose `host.js` or `resident.js` runs it (directly, or through that link).

## The one-shot host

`src/host.ts` is the Generation 1 host, the twin of the Python SDK's `furnace.host`.
`node dist/src/host.js --app <module>[:<export>] [--executor <name>] [--result-file <path>]`
imports the definition (a path is resolved against the host's working directory, which
under Furnace defaults to the workspace; without `:<export>` the module must export exactly
one `ExecutorApp`), reads one ExecutionContext document from stdin (written once, then
end-of-file), selects exactly one registered callback (`--executor` may be omitted when the
definition registers exactly one), and writes its ExecutionResult, whole, exactly once, to
`--result-file` or to `<workspace.root>/.furnace/results/<attempt_id>.json`. `runApp(app)`
is the same host for a definition that is its own program
(`node my_executor.js --executor <name> --result-file <path>`).

The exit is the result's status and nothing else (FRN-HOST-008, `EXIT_BY_STATUS`): every
`failure` exits 10 whatever its `failure_class`. Host and protocol failures are distinct
from every result status and from node's own 1:

| constant | exit | when |
|---|---|---|
| `EXIT_SUCCESS` | 0 | the callback returned `success` |
| `EXIT_USAGE` | 2 | the command line could not be read, or several executors are registered and `--executor` was not given |
| `EXIT_CONTEXT_DECODE_FAILURE` | 3 | stdin did not hold one valid ExecutionContext document |
| `EXIT_RESULT_CHANNEL_FAILURE` | 4 | the result file could not be prepared or written |
| `EXIT_APP_LOAD_FAILURE` | 5 | `--app` did not import (a registration refused while it did included), or its module exports no `ExecutorApp`, or several and no `:<export>` |
| `EXIT_RESULT_FAILURE` | 10 | the callback returned (or rejected into) `failure` |
| `EXIT_RESULT_CANCELLED` | 11 | the callback returned `cancelled` |
| `EXIT_RESULT_INDETERMINATE` | 12 | the callback returned `indeterminate` |

An `[executors.<name>]` table runs it with `program = "node"`. `<repo>` and the definition
path stand for absolute paths:

```toml
[execution]
executor = "coder"

[executors.coder]
program = "node"
args = ["<repo>/sdk/typescript/dist/src/host.js", "--app", "<definition>", "--executor", "coder"]
context = "stdin-json"   # the host reads the context from stdin only
```

In Generation 1 the exit is all Furnace consumes: under this process definition Furnace
judges the step by the host's exit alone and does not read the result file, so a natural
exit 0 is success and closes the Work, and any other natural exit is a `work_failure`
Attempt.

## The resident host

`node dist/src/resident.js --app <module>[:<export>] --executor <name>` serves the same
definition over `furnace.executor.v1`, JSON Lines on stdin and stdout
(`04-low-level-design.md` §6):

```toml
[execution]
executor = "coder"

[executors.coder]
program = "/absolute/path/to/node"   # the extension driver does not search PATH
args = ["<repo>/sdk/typescript/dist/src/resident.js", "--app", "<definition>", "--executor", "coder"]
driver = "extension"
```

Pass `--executor`: an extension definition runs exactly one executor, and Furnace refuses a
host that advertises more (`executor_start_failed`). Furnace sends the versioned context,
which carries `context_version: 1` (the process driver's document has no `context_version`
member at all; the SDK reads that as transport version 0, so a one-shot callback sees
`ctx.context_version` 0 and this one sees 1), no result file is written, a callback's
`console.log` goes to the host's stderr, which reaches Furnace's own stderr, and Furnace
acts on the terminal result's status only (`failure`, whatever its class, is a
`work_failure` Attempt). The host runs one execution at a time and cannot observe or cancel
one.

Each advertised executor carries its durability profile: the third argument of
`app.executor(name, callback, { durability })` declares, by the model's `DurabilityProfile`
member names (`executor-protocol/model/common.smithy`), what the host can do durably. Every
member is false unless declared, so an executor that declares nothing is a valid executor
that claims nothing; a declaration is refused at registration (`RegistrationError`) when it
names a member outside the model or breaks a rule of
`executor-protocol/registry/durability-profile-rules.json` (for example `restore` without
`checkpoint`). A durable operation whose gating member the executor declared false is
answered `{"status": "unsupported"}` and never enters a callback; this host revision carries
no handler for one declared true and refuses it as an `ExecutorProtocolError`. One member
qualifies `execute` itself: for an executor declaring `deduplicate_admission`, a repeated
`execute` for an `execution_id` the host already accepted is acknowledged again with the same
receipt and nothing else (no second `started`, no callback, no second execution), so a driver
that lost the first acknowledgement recovers it by resending; without that declaration, and
for a repeat that names another executor, the repeat is refused as an `ExecutorProtocolError`.

```ts
app.executor("coder", async (ctx) => ExecutionResult.success({ summary: "done" }), {
  durability: { checkpoint: true, checkpoint_survives_host_restart: true },
});
```

## The conformance CLI

`dist/src/conformance.js` is the package's conformance CLI: `decode-context`,
`decode-result`, `encode-result`, `list-statuses`, and `run-battery`
(`--registry PATH --evidence-out PATH --subject-host ARGV --obligations PATH`). `run-battery`
runs the cases the registry applies to `sdk-typescript`, then adds one record for each
model-derived obligation that applies to it, read from `--obligations PATH` or by default
from `executor-protocol/generated/registries/model-obligations.json` (19 records at this
revision). Its own summary row and exit count the registry's mandatory cases only
(`expected=31`). The engine passes the evidence only when given the same obligations
(from the repository root, after `npm run build`):

```sh
node sdk/typescript/dist/src/conformance.js run-battery --evidence-out evidence.json
python3 scripts/executor_conformance.py verdict \
  --obligations executor-protocol/generated/registries/model-obligations.json --evidence evidence.json
# tier=executor-conformance expected=50 executed=50 passed=50 ... verdict=pass (exit 0)
```

Without `--obligations`, `verdict` reports each obligation record as not in the registry,
recomputes the summary to `verdict=fail` and exits 1
(`tests/shell/integration/typescript_sdk_passes_the_shared_conformance_battery.sh`).

## Progress and notice events

Every context a host hands a callback also carries `ctx.events` (04 §3.4), typed as
`CallbackContext`:

```ts
app.executor("coder", async (ctx) => {
  const { events } = ctx as CallbackContext;
  await events.progress({ message: "Planning", fraction: 0.1 });
  await events.notice("Launching model");
  // ...
});
```

- `message` is a string; `fraction` is optional and, when given, a finite number from 0 to 1
  inclusive. Any other argument throws at the call (`TypeError` or `RangeError`) and emits
  nothing, and so does a call made after the callback has returned.
- The payloads are `{"message", "fraction"}` (no `fraction` key when none was given) and
  `{"message"}`. Each event is written before the call returns.
- Under the resident host (`node dist/src/resident.js`) each call is one `progress` or `notice`
  event at the next sequence after `started`, before the `terminal`. Under the one-shot host it
  is one stderr line, `furnace.host: event <kind> <payload as compact JSON>`, so the same
  callback runs under either host unchanged.
- `events` is a non-enumerable property beside the model's members: the context's keys, JSON
  and deep equality are exactly the decoded `ExecutionContext`'s.

## Driving Furnace

Illustrative: the workspace path and the formula are placeholders for your own.

```ts
import { Furnace, FurnaceCommandError } from "@furnace/sdk";

const furnace = new Furnace({ binary: "furnace", cwd: "/repo" });

const version = await furnace.version();          // Response<VersionDto>, protocol_version gated first
const run = await furnace.runs.start({            // StartedRun: id, record (RunDto), requestId
  formula: "feature-development",
  vars: { issue: "bd-123" },
});

for await (const event of run.events()) {         // `logs --follow <run-id> --jsonl`
  console.log(event.sequence, event.type);
}

try {
  await furnace.runs.status("frn-run-absent");
} catch (error) {
  if (error instanceof FurnaceCommandError) {
    error.code;       // "run_not_found" in an initialized state root; a fresh one answers "state_error"
    error.retryable;  // from the envelope, not re-derived
    error.exit.code;  // 7 (1 for state_error), the code's exit class as observed
  }
}
```

- `cwd` becomes the global `-C` flag (the child keeps this process's working directory),
  `stateDir` `--state-dir` and `config` `--config`; `env` entries are laid over
  `process.env` for the child. Every method that runs a command takes `{ requestId }`
  (`--request-id`).
- `runs.start` resolves when `run start` returns, after the Run's foreground supervision
  ends. No option selects a configured executor: the Run takes `[execution] executor`, and
  `executorProgram` is the `--executor-program` bypass.
- The client covers `version`, `doctor`, `runs.start` / `status` / `list` / `get`,
  `run.status` and `run.events`; for any other command, run the CLI with `--json`.

## What the types promise

- DTO payloads (`response.data`, `run.record`) keep the wire's snake_case, as the documented
  envelopes (`crates/furnace-protocol`) spell them. The envelope wrapper (`Response`)
  exposes `protocolVersion`, `requestId` and `kind`; a `FurnaceCommandError` exposes
  `protocolVersion`, `requestId` and `responseKind` (the error envelope's own `kind`).
- `protocol_version` is read first and alone. A version outside
  `SUPPORTED_PROTOCOL_VERSIONS` is an `IncompatibleProtocolError` carrying the observed
  version and the supported range, and no field of the payload.
- A Furnace error envelope is a `FurnaceCommandError` with its `code` (a `code` outside
  `ERROR_CODES` is refused as `MalformedOutputError`). The client's own observations —
  `MalformedOutputError`, `ProcessFailedError`, `UnexpectedResponseKindError`,
  `StreamTruncatedError`, `StreamOrderError`, `BinaryUnavailableError`, `RequestTimeoutError` — each
  carry what was
  actually observed (bytes and exit status where there were any) and never a fabricated
  verdict. These, and the decode and registration errors, are `FurnaceError` subclasses
  with a `kind` discriminant. Some failures are not: `ContractUnavailableError` (an install
  with no shipped contract), the host's `DefinitionLoadError`, the plain `Error` from iterating
  one `EventStream` twice, and the `TypeError` `runs.start` throws on a success envelope
  whose `data` is `null`.
- `run.events()` yields each JSONL line as it arrives. At protocol 1 the stream is
  `logs --follow`: the `attempt.output` events of one Attempt (the Run's newest, or the one
  `{ work }` / `{ attempt }` names), ending when the CLI exits 0 after that Attempt
  finishes, with `stream.terminalEvent` `null`. The terminal Run kinds
  (`run.completed`/`run.stopped`/`run.failed`) are part of the contract, and iteration
  would also complete on one, but this binary's follow stream does not emit them. Any other
  end is `StreamTruncatedError`, including a refused follow, whose error envelope is then
  only in `.stderr`.
- Additive unknown fields within a compatible protocol version are ignored (FRN-PRO-002).
  The event reader requires `type` to be a string and does not hold it to `EVENT_KINDS`
  (`FurnaceEvent.type` is `EventKind | (string & {})`), so an event of a kind that roster
  does not list is still yielded.
- Streams follow the CLI's rule: a success document is read from stdout, and when stdout
  is empty the one error envelope the CLI writes to stderr is read from there. A stdout
  document is always the truth; stderr prose beside it is diagnostics, exposed as
  `response.stderr`. A success document with a nonzero exit is returned, not thrown
  (`response.exit`).
- Every buffer the transport holds is bounded (`TransportLimits` / `DEFAULT_LIMITS` in
  `src/transport.ts`, measured in string length): a captured `--json` stdout document holds
  at most 64 Mi characters (past it the child is killed and the call rejects with
  `MalformedOutputError`, since a prefix is not a document), stderr keeps its last 1 Mi
  characters (earlier text is dropped and the kept tail starts with a
  `[furnace sdk: N earlier stderr characters dropped; ...]` marker), a streamed stdout line
  holds at most 16 Mi characters (an overlong fragment is `MalformedOutputError`), and a
  stream holds at most 1024 unread lines plus one 64 KiB read chunk before it pauses the
  child's stdout until the consumer catches up.

## Developing

Node 22 or newer (`engines`), with type stripping on by default
(`node -p process.features.typescript` prints `strip`): the SDK loads the generated
contract's TypeScript source with `require()`, and a Node that does not strip types fails
at the first decode. Dependencies are dev-only (`typescript`, `@types/node`), pinned, with
`package-lock.json` committed.

```sh
npm ci
npm test
```

`npm test` compiles to `dist/` and runs the suite with `node --test`. Among its files:

- `test/battery.test.ts` — the shared contract battery: one test per case id in
  `tests/fake-furnace/cases.json`, replayed against the fake `furnace`, plus a final check
  that the executed-case ledger equals the manifest (ten cases).
- `test/error_code_denominator.test.ts` — every `ErrorCode` instantiated through the fake,
  each arriving typed, with the list held to `ErrorCode::ALL` in the protocol crate.
- `test/argv.test.ts` — the argv the client hands the binary.
- `test/lifecycle_verbs.test.ts` — the Run lifecycle verbs (`runs.adopt/resume/pause/stop`,
  `attempts.list/inspect/stop`, `work.retry`, `logs.read`) read back from a recording binary,
  and the per-request timeout against a stalled fake: typed, inside the bound, child reaped.
- `test/real_binary.test.ts` — the real-binary journey (`target/debug/furnace`, or
  `FURNACE_TEST_BIN`); skipped, and reported as skipped, when no binary is present.
- `test/success_paths.test.ts` — `doctor()`, `runs.status()` and `runs.list()` decoded from
  the fake and from the real binary, each payload type pinned by a key table; the real leg is
  skipped, and reported as skipped, when no binary is present.
- `test/event_stream_protocol_gate.test.ts` — the per-line protocol gate of `run.events()`
  and the `StreamOrderError` on a `sequence` that does not increase.
- `test/contract_packaged_copy.test.ts` — the shipped copy of the generated contract
  (`contract/`, the build product of `scripts/sync_sdk_contract.py --write`): a copy of the
  built package outside a checkout loads it from its own directory, the manifest's model
  digest equals the loaded module's, and a manifest naming another model than its module
  is a `ContractUnavailableError`.
- the executor half: `test/executor_app.test.ts`, `test/models.test.ts`,
  `test/host.test.ts`, `test/resident_host.test.ts`, `test/async_is_primary.test.ts`,
  `test/promise_callbacks_are_awaited.test.ts`, `test/callback_signature_is_host_neutral.test.ts`,
  `test/two_apps_do_not_share_a_registry.test.ts`, `test/streaming.test.ts` (callback
  output streamed through the host before its terminal result) and
  `test/callback_events.test.ts` (`ctx.events` progress and notice under both hosts);
  `test/durability_declaration.test.ts` and `test/resident_durability.test.ts` (the durability
  declaration's projection of the model's `DurabilityProfile`, refused at registration when it
  breaks the registry's profile rules, advertised by the resident host, and a false claim's
  durable operation answered `unsupported` without entering the callback);
  `test/resident_admission.test.ts` (admission deduplicated by `execution_id` for an executor
  declaring `deduplicate_admission`, with the non-deduplicating control host under
  `test/hosts/` that the same assertion must fail against); the
  client's protocol gate and transport boundary in `test/protocol_version_predicate.test.ts`
  and `test/transport_privacy.test.ts`; the transport's memory bounds in
  `test/transport_bounds.test.ts` (stdout, stderr, line and queue bounds each driven past by
  a child, each beside a control under the default bound); and `test/vocabulary_parity.test.ts`, which holds
  `ERROR_CODES`, `RESPONSE_KINDS` and `EVENT_KINDS` to the generated skill reference's tables.

`scripts/test.sh sdk-typescript` runs this suite as a mandatory tier
(`tests/shell/sdk-typescript/the_typescript_client_suite_passes_under_node_test.sh`); running
it from this directory is the same suite. The tier compiles with the pinned `typescript`
under `node_modules` (installing it with `npm ci` when it is absent) into scratch, and
reports PEND when there is no Node at the `engines` floor, or when the compiler is absent
and there is no `npm` to install it with or its `npm ci` fails (for example, the registry
is unreachable).
