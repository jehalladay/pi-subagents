# @furnace/sdk (TypeScript)

The Furnace executor SDK for TypeScript, one package (`docs/executor-platform/04-low-level-design.md`
§4): the executor half (`ExecutorApp`, `ExecutionContext`, `ExecutionResult`) with its
Generation 1 one-shot host (`dist/src/host.js`) and Generation 2 resident host
(`dist/src/resident.js`, for an `[executors.<name>]` table with `driver = "extension"`), a
conformance CLI (`dist/src/conformance.js`), and a typed client for Furnace's versioned
machine interface over the `furnace` CLI's `--json` and `--jsonl` modes (§8).

This page is the short version. The maintained usage guide (entry points, exits, errors,
and recipes run against the binary) is the Furnace skill's
[`references/sdk-typescript.md`](../../crates/furnace-cli/skills/furnace/references/sdk-typescript.md);
executor definitions, both drivers and the `furnace.executor.v1` wire are in
[`references/executor-platform.md`](../../crates/furnace-cli/skills/furnace/references/executor-platform.md).

## Defining an executor

```ts
import { ExecutorApp, ExecutionResult, type ExecutionContext } from "@furnace/sdk";

export const app = new ExecutorApp();

app.executor("coder", async (ctx: ExecutionContext) => {
  // ctx is the typed context in the wire's own spelling: ctx.work.beads_work_id,
  // ctx.attempt.ordinal, ctx.work.title (string | null: absent text is null, never "").
  return ExecutionResult.success({ summary: `saw ${ctx.work.beads_work_id}` });
});
```

- A bare `async (ctx) => Promise<ExecutionResult>` is the whole API; a synchronous callback
  is accepted too. `defineExecutor(name, cb)` is the standalone form: a declaration value an
  app registers later with `app.register(declaration)`, starting nothing at definition time.
  `ExecutionContext`, its four group types, `ExecutionStatus` and `FailureClass` are
  type-only exports, so import them with `type`.
- Names are exact, case-sensitive protocol identifiers; an empty name, or one with
  surrounding whitespace or a control character, is a `RegistrationError`, a second
  registration of a name a `DuplicateExecutorError`, both at registration time. Two apps in
  one process share nothing (no module-level registry).
- `ExecutionResult.success({ summary?, data? })`,
  `.failure(message, { failure_class?, data? })` (the class is one of `"task"`,
  `"executor"`, `"transient"`, `"configuration"`; it defaults to `"executor"`, and a
  `"task"` failure stays distinct), `.cancelled(message?)`, `.indeterminate(message)`: four
  constructors, four statuses, serialized as the model's exact strings. A failed or
  indeterminate result requires diagnostic text.
- The shipped hosts classify a callback through `runCallback`: a rejection becomes `failure`
  with `failure_class: "executor"`, `callback "<name>" raised <Kind>: <message>` as the
  diagnostic and `{ exception_type, exception_message }` as `data`; a value that is not an
  `ExecutionResult` is `failure` / `"executor"`; an unregistered name is `failure` /
  `"configuration"` from the one-shot host, while the resident host refuses an execute
  naming an executor it does not serve. `app.settle(name, ctx)` is the in-process mapping, with
  `<ErrorName>: <message>` as the diagnostic and an unregistered name rejected with
  `UnknownExecutorError`. Neither guesses that an arbitrary error is transient.
- Validation is the generated contract's: every decode that reaches shape validation uses
  the Smithy-derived validators under `executor-protocol/generated/typescript` (loaded from
  their canonical path, never copied). The SDK's own checks run around them: before, the
  root-object check and then the `context_version` selection (contexts) or the dropping of
  key-present `null` members (results); after, the 32-bit ordinal ceiling (contexts) or the
  failure-class and summary rules (results). `contractProvenance()` reports the model
  digest read from the artifact's manifest.

## Installing

The package declares no `bin` and no `exports` map; `files` ships `dist/src`,
`dist/contract` and `contract/{manifest.json,registry,fixtures,generated}` and leaves
`dist/test` out. The SDK validates against `executor-protocol/generated/typescript`, a copy
of which ships inside the package: `contract/` is a git-ignored build product
`scripts/sync_sdk_contract.py --write` copies from the committed artifact (the generated
sources, their `manifest.json` naming the model digest and protocol version, the
registry's durability rule set, and the conformance corpus `run-battery` reads: the case
registry, the fixtures its SDK cases name and the model-derived obligations; beside them the
exception battery `BEH-004` drives, copied to `contract/executors/` from
`test/executors/exception_battery.ts`) and `npm run build` runs first, so `tsc` compiles the
copy to `dist/contract/` beside `dist/src/`. A tarball from `npm pack` therefore validates
when installed anywhere; the committed artifact stays the one source the smithy drift
check convicts, and the loader refuses a copy whose manifest digest disagrees with the
provenance module it carries. An install whose copy is missing throws
`ContractUnavailableError` at its first decode.

```sh
cd sdk/typescript
npm ci
npm run build    # writes dist/, which is not committed; npm test rebuilds it from clean
```

A package of your own can then depend on it by path: `npm install <repo>/sdk/typescript`
links it as `node_modules/@furnace/sdk`, which the imports in this README assume. The hosts pick a
definition's app by class identity, so a definition imports the SDK from the same
`dist/src` whose `host.js` or `resident.js` runs it (directly, or through that link).

## The one-shot host

`src/host.ts` is the Generation 1 host, the twin of the Python SDK's `furnace.host`.
`node dist/src/host.js --app <module>[:<export>] [--executor <name>] [--result-file <path>]`
imports the definition (a path is resolved against the host's working directory, which
under Furnace defaults to the workspace; without `:<export>` the module must export exactly
one `ExecutorApp`), reads one ExecutionContext document from stdin (written once, then
end-of-file), selects exactly one registered callback (`--executor` may be omitted when the
definition registers exactly one), and writes its ExecutionResult, whole, exactly once, to
`--result-file` or to `<workspace.root>/.furnace/results/<attempt_id>.json`. `runApp(app)`
is the same host for a definition that is its own program
(`node my_executor.js --executor <name> --result-file <path>`).

The exit is the result's status and nothing else (FRN-HOST-008, `EXIT_BY_STATUS`): every
`failure` exits 10 whatever its `failure_class`. Host and protocol failures are distinct
from every result status and from node's own 1:

| constant | exit | when |
|---|---|---|
| `EXIT_SUCCESS` | 0 | the callback returned `success` |
| `EXIT_USAGE` | 2 | the command line could not be read, or several executors are registered and `--executor` was not given |
| `EXIT_CONTEXT_DECODE_FAILURE` | 3 | stdin did not hold one valid ExecutionContext document |
| `EXIT_RESULT_CHANNEL_FAILURE` | 4 | the result file could not be prepared or written |
| `EXIT_APP_LOAD_FAILURE` | 5 | `--app` did not import (a registration refused while it did included), or its module exports no `ExecutorApp`, or several and no `:<export>` |
| `EXIT_RESULT_FAILURE` | 10 | the callback returned (or rejected into) `failure` |
| `EXIT_RESULT_CANCELLED` | 11 | the callback returned `cancelled` |
| `EXIT_RESULT_INDETERMINATE` | 12 | the callback returned `indeterminate` |

An `[executors.<name>]` table runs it with `program = "node"`. `<repo>` and the definition
path stand for absolute paths:

```toml
[execution]
executor = "coder"

[executors.coder]
program = "node"
args = ["<repo>/sdk/typescript/dist/src/host.js", "--app", "<definition>", "--executor", "coder"]
context = "stdin-json"   # the host reads the context from stdin only
```

In Generation 1 the exit is all Furnace consumes: under this process definition Furnace
judges the step by the host's exit alone and does not read the result file, so a natural
exit 0 is success and closes the Work, and any other natural exit is a `work_failure`
Attempt.

## The resident host

`node dist/src/resident.js --app <module>[:<export>] --executor <name>` serves the same
definition over `furnace.executor.v1`, JSON Lines on stdin and stdout
(`04-low-level-design.md` §6):

```toml
[execution]
executor = "coder"

[executors.coder]
program = "/absolute/path/to/node"   # the extension driver does not search PATH
args = ["<repo>/sdk/typescript/dist/src/resident.js", "--app", "<definition>", "--executor", "coder"]
driver = "extension"
```

Pass `--executor`: an extension definition runs exactly one executor, and Furnace refuses a
host that advertises more (`executor_start_failed`). Furnace sends the versioned context,
which carries `context_version: 1` (the process driver's document has no `context_version`
member at all; the SDK reads that as transport version 0, so a one-shot callback sees
`ctx.context_version` 0 and this one sees 1), no result file is written, a callback's
`console.log` goes to the host's stderr, which reaches Furnace's own stderr, and Furnace
acts on the terminal result's status only (`failure`, whatever its class, is a
`work_failure` Attempt). The host runs one execution at a time and cannot observe or cancel
one.

Each advertised executor carries its durability profile: the third argument of
`app.executor(name, callback, { durability })` declares, by the model's `DurabilityProfile`
member names (`executor-protocol/model/common.smithy`), what the host can do durably. Every
member is false unless declared, so an executor that declares nothing is a valid executor
that claims nothing; a declaration is refused at registration (`RegistrationError`) when it
names a member outside the model or breaks a rule of
`executor-protocol/registry/durability-profile-rules.json` (for example `restore` without
`checkpoint`). A durable operation whose gating member the executor declared false never
enters a method, even when a provider carries one, and is answered in the operation's own
vocabulary: `checkpoint`, `restore` and `replay_events` with `{"status": "unsupported"}`, and
`resolve_execution`, whose `ResolutionStatus` carries no such word, with an
`ExecutorProtocolError` naming the operation, the executor and `resolve_by_execution_id` (the
module comment of `src/resident.ts` gives the reason). One declared true is dispatched into
the executor's one optional continuity provider (below), and a true member whose executor
passes no provider method is refused as an `ExecutorProtocolError`, never answered
`unsupported`. One member
qualifies `execute` itself: for an executor declaring `deduplicate_admission`, a repeated
`execute` for an `execution_id` the host already accepted is acknowledged again with the same
receipt and nothing else (no second `started`, no callback, no second execution), so a driver
that lost the first acknowledgement recovers it by resending; without that declaration, and
for a repeat that names another executor, the repeat is refused as an `ExecutorProtocolError`.

```ts
app.executor("coder", async (ctx) => ExecutionResult.success({ summary: "done" }), {
  durability: { checkpoint: true, checkpoint_survives_host_restart: true },
});
```

The continuity provider is the `continuity` member of the same options object
(`app.executor(name, callback, { durability, continuity })`, `app.register(...)` and
`defineExecutor(...)` alike); `app.continuity(name)` reads the normalized `ContinuityProvider`
back (`undefined` when the registration passed none; `UnknownExecutorError` for an unregistered
name, like `app.durability(name)`). A provider is any object whose methods are named by the
durable operations' wire spelling — `checkpoint`, `restore`, `resolve_execution`,
`replay_events` — plus the advisory `cancel` (`interface ContinuityProvider { readonly
checkpoint?: CheckpointMethod; readonly restore?: RestoreMethod; readonly resolve_execution?:
ResolveMethod; readonly cancel?: CancelMethod }`). This SDK revision binds `checkpoint`,
`restore` and `resolve_execution` (`BOUND_OPERATIONS` is `["checkpoint", "restore",
"resolve_execution"]`: the durable operations the generated contract models; the constant grows
with each operation's landing and never follows the contract silently), so registration refuses
(`RegistrationError`) a non-object provider (a string, a number, an array, ... named by type), a
provider naming none of the four gates nor `cancel` (below), a method under an unbound name
(`replay_events`, naming the operation and its generated `<Operation>Input` /
`<Operation>Output` shapes) and a non-function method or `cancel` member; a method for a member
declared false is accepted and never entered.

The `checkpoint` method receives a `CheckpointRequest { execution_id, receipt, context }` — the
Furnace-minted id the host accepted, the ACTIVE receipt of that admission (the one the
`execute` acknowledgement carried; receipts come from one session-wide monotonic counter per
host) and the retained `ExecutionContext` — and returns a `CheckpointOutcome`, plain or
promised: `CheckpointOutcome.created(ref)` with a `CheckpointRef` naming the same execution and
the deciding executor (`opaque_reference` passes through untouched), `failed(diagnostic)`,
`alreadyTerminal()` or `unknown(diagnostic)`; the class is nominal (a private brand), so a
plain `{ status: "created" }` is refused as a wrong-typed return, and the host validates the
outcome under the generated `CheckpointOutput` before writing it. Before the method is entered
the host refuses, as an `ExecutorProtocolError` naming the operation and the executor: an
input that does not validate as `CheckpointInput` (a missing receipt included), an execution
it never accepted, and a receipt other than the active one (naming both); a checkpoint for an
incarnation whose terminal is already written is answered `{"status": "already_terminal"}` by
the host from its own maps, the method not entered. After the method it refuses a reference
naming another execution or bound to another executor (naming both), a method that threw
(naming the error's class), a return that is not a `CheckpointOutcome` (naming the type) and
an outcome that fails the output shape — never a false `created`; the host keeps serving. A
durable operation whose generated shapes the shipped contract lacks (`replay_events` today), or
whose shapes are present but which this revision binds no method for, is refused when declared
true, naming the operation and both shapes.

The `restore` method receives a `RestoreRequest { execution_id, checkpoint, context,
restore_request_id }` — the id, the confirmed `CheckpointRef` a checkpoint returned for it, the
CURRENT versioned `ExecutionContext` decoded from the request and the stable identity of the
restore decision — and returns a `RestoreOutcome`, plain or promised:
`RestoreOutcome.restored(resume)` hands the host a continuation (shaped like a callback, classified
by the same classifier) that it runs as a NEW incarnation under a receipt it mints from the same
counter (`started` at sequence 0, its events, one terminal; Cancel, Observe and Checkpoint then
address the new receipt, and the superseded one is refused or `unknown`); `terminal(result)`
answers the already-authoritative `ExecutionResult` as the identified `TerminalResult` and starts
nothing; `refused(refusal, message)` carries a `RestoreRefusal` word; `unknown(message)`. The
domains are the generated `RESTORE_STATUS_VALUES` / `RESTORE_REFUSAL_VALUES` (`restoreStatuses()`,
`restoreRefusals()`), the class is nominal, and the outcome travels in the Restore reply, never as
an exit status. The host owns the operation's identity rules: the owner is the executor that
accepted the id or, on a fresh host process, the executor the checkpoint is bound to; a checkpoint
naming another execution is answered `refused` / `checkpoint_wrong_execution` without entering the
method; a resend of a decision already restored (the same `restore_request_id`) is answered with
the same receipt and nothing else, and a NEW decision while an incarnation runs is refused. The
`resolve_execution` method receives a `ResolveRequest { execution_id, known_receipt? }` — the
receipt this host process holds, absent on a fresh process — and returns a `ResolveOutcome`:
`found(receipt, observation?)`, `notFound()` or `unknown(diagnostic?)` (generated
`RESOLUTION_STATUS_VALUES`, `resolutionStatuses()`); where the host holds the execution, a `found`
receipt other than the active one or `not_found` is refused as a contradiction, never replaced, and
where it holds none the answer is replied and nothing is recorded.

```ts
import { CheckpointOutcome, type CheckpointRequest, type ContinuityProvider } from "@furnace/sdk";

const provider: ContinuityProvider = {
  // illustrative: the reference's members are the generated CheckpointRef's
  async checkpoint(request: CheckpointRequest) {
    return CheckpointOutcome.created({
      checkpoint_id: "cp-1",
      execution_id: request.execution_id,
      driver: "extension",
      executor_name: "coder",
      format_version: "1",
      durability: { survives_controller_restart: true, survives_host_restart: true, survives_machine_restart: false, provider_managed: false },
      opaque_reference: { path: `${request.context.workspace.root}/cp-1` },
    });
  },
};

app.executor("coder", async (ctx) => ExecutionResult.success({ summary: "done" }), {
  durability: { checkpoint: true },
  continuity: provider,
});
```

The provider may also carry `cancel`, an ADVISORY method that binds no durable operation
(`cancel` is not in `BOUND_OPERATIONS`: Cancel is a base operation every host answers). A
Cancel naming an execution this host process never admitted is asked of the CLAIMANTS — the
served executors whose profile declares `cancel_after_controller_restart`
(`CONTINUITY_CANCEL_MEMBER`) and whose provider carries `cancel` — so a fresh host process
answers for an execution an earlier process admitted, from the executor's durable state,
admitting nothing (no `started` follows). The method receives a
`CancelRequest { execution_id, reason }` and returns a `ContinuityState`, plain or promised —
`ContinuityState.running()`, `.ended()` or `.unknown()`: the executor's state as the provider
truthfully knows it. The host alone writes the `CancelStatus`, mapping the state through
`CANCEL_STATUS_OF_STATE` (`running` → `request_received`, `ended` → `already_terminal`,
`unknown` → `unknown_execution`); a wire word (`request_received`) or a verdict word
(`cancelled`) is not a state — `ContinuityState.fromDocument` refuses it as out of the domain,
and a method resolving to anything but a `ContinuityState` instance (a plain
`{ state: "running" }` included) is refused before any reply is written. An execution this
process admitted is answered from the host's own maps, the method not entered; a non-claimant —
a member declared false, or a provider without `cancel` — is never entered and is never a reason
to refuse; no claimant, or every claimant `unknown`, is `unknown_execution` as before. A method
that throws or resolves to anything but a `ContinuityState`, and two claimants that both report
an execution under one id (one execution id belongs to one execution), are refused as
`ExecutorProtocolError` naming `cancel`, the executor and the cause; the host keeps serving. A
provider carrying only `cancel` is a valid provider. The names (`ContinuityState`,
`CancelRequest`, `CancelMethod`, `CANCEL_STATUS_OF_STATE`, `CONTINUITY_CANCEL_MEMBER`) are
exported by `src/durability.ts`.

```ts
import { ContinuityState, type CancelRequest, type ContinuityProvider } from "./durability.js"; // src/durability.ts

const provider: ContinuityProvider = {
  // illustrative: the state is read from the executor's own durable record
  async cancel(request: CancelRequest) {
    const record = await loadRecord(request.execution_id); // your store, written by the process that admitted it
    if (record === undefined) return ContinuityState.unknown();
    return record.terminal ? ContinuityState.ended() : ContinuityState.running();
  },
};

app.executor("coder", async (ctx) => ExecutionResult.success({ summary: "done" }), {
  durability: { cancel_after_controller_restart: true },
  continuity: provider,
});
```

## The conformance CLI

`dist/src/conformance.js` is the package's conformance CLI: `decode-context`,
`decode-result`, `encode-result`, `list-statuses`, and `run-battery`
(`--registry PATH --evidence-out PATH --subject-host ARGV --obligations PATH`). `run-battery`
runs the cases the registry applies to `sdk-typescript`, then adds one record for each
model-derived obligation that applies to it, read from `--obligations PATH` or by default
from `generated/registries/model-obligations.json` beside the registry it read (19 records
at this revision). Without `--registry` the registry is the copy the package ships
(`contract/registry/conformance-cases.json`), else, inside a checkout whose shipped copy is
absent, `executor-protocol/registry/conformance-cases.json`; neither is refused (exit 2)
naming both paths, and `--registry PATH` overrides both, so an installed tarball runs the
shared battery from its own corpus and passes it whole (`BEH-004` drives the exception battery
the package ships, `dist/contract/executors/exception_battery.js`, else the test tree's compiled
`dist/test/executors/` in a checkout; neither fails `BEH-004` naming both paths; `BEH-005`
drives the package's own `ResidentSession`, in a child `node`, over `dist/src/conformance_battery.js`'s
cooperative `cancel` arm and records the host's Cancel and Observe answers in order, the evidence
for the advertised `cancel`). Its own summary row and exit count the registry's mandatory cases only
(`expected=40`). The engine passes the evidence only when given the same obligations
(from the repository root, after `npm run build`):

```sh
node sdk/typescript/dist/src/conformance.js run-battery --evidence-out evidence.json
python3 scripts/executor_conformance.py verdict \
  --obligations executor-protocol/generated/registries/model-obligations.json --evidence evidence.json
# tier=executor-conformance expected=59 executed=59 passed=59 ... verdict=pass (exit 0)
```

Without `--obligations`, `verdict` reports each obligation record as not in the registry,
recomputes the summary to `verdict=fail` and exits 1
(`tests/shell/integration/typescript_sdk_passes_the_shared_conformance_battery.sh`).

## Progress and notice events

Every context a host hands a callback also carries `ctx.events` (04 §3.4), typed as
`CallbackContext`:

```ts
app.executor("coder", async (ctx) => {
  const { events } = ctx as CallbackContext;
  await events.progress({ message: "Planning", fraction: 0.1 });
  await events.notice("Launching model");
  // ...
});
```

- `message` is a string; `fraction` is optional and, when given, a finite number from 0 to 1
  inclusive. Any other argument throws at the call (`TypeError` or `RangeError`) and emits
  nothing, and so does a call made after the callback has returned.
- The payloads are `{"message", "fraction"}` (no `fraction` key when none was given) and
  `{"message"}`. Each event is written before the call returns.
- Under the resident host (`node dist/src/resident.js`) each call is one `progress` or `notice`
  event at the next sequence after `started`, before the `terminal`. Under the one-shot host it
  is one stderr line, `furnace.host: event <kind> <payload as compact JSON>`, so the same
  callback runs under either host unchanged.
- `events` is a non-enumerable property beside the model's members: the context's keys, JSON
  and deep equality are exactly the decoded `ExecutionContext`'s.

## Driving Furnace

Illustrative: the workspace path and the formula are placeholders for your own.

```ts
import { Furnace, FurnaceCommandError } from "@furnace/sdk";

const furnace = new Furnace({ binary: "furnace", cwd: "/repo" });

const version = await furnace.version();          // Response<VersionDto>, protocol_version gated first
const run = await furnace.runs.start({            // StartedRun: id, record (RunDto), requestId
  formula: "feature-development",
  vars: { issue: "bd-123" },
});

for await (const event of run.events()) {         // `logs --follow <run-id> --jsonl`
  console.log(event.sequence, event.type);
}

try {
  await furnace.runs.status("frn-run-absent");
} catch (error) {
  if (error instanceof FurnaceCommandError) {
    error.code;       // "run_not_found" in an initialized state root; a fresh one answers "state_error"
    error.retryable;  // from the envelope, not re-derived
    error.exit.code;  // 7 (1 for state_error), the code's exit class as observed
  }
}
```

- `cwd` becomes the global `-C` flag (the child keeps this process's working directory),
  `stateDir` `--state-dir` and `config` `--config`; `env` entries are laid over
  `process.env` for the child. Every method that runs a command takes `{ requestId }`
  (`--request-id`).
- `runs.start` resolves when `run start` returns, after the Run's foreground supervision
  ends. No option selects a configured executor: the Run takes `[execution] executor`, and
  `executorProgram` is the `--executor-program` bypass. A configured executor is selected
  by `[execution] executor` in the file `config` names, or by `FURNACE_EXECUTOR` in `env` on
  `new Furnace({...})` (laid over `process.env` for the child).
- Which commands have a client operation, which are excluded and which are still owed is the
  `Client operations` table of
  `crates/furnace-cli/skills/furnace/references/generated-reference.md`, generated from the
  binary's `cli::CLIENT_OPERATIONS`; `test/client_surface_parity.test.ts` holds this client's
  public surface to it. For a command without a `mirrored` row, run the CLI with `--json`.

### Hosting the callback in your own process

Generation 3 (`docs/executor-platform/01-product-vision.md` §6; decision `D308`): the
application that drives the Run also hosts the executor callback, so the callback runs
where the application's objects live — no definition module, no second process for it.

```ts
import { ExecutionResult, Furnace } from "@furnace/sdk";

const furnace = new Furnace({ binary: "furnace", cwd: "/repo" });

furnace.executor("coder", async (ctx) => ExecutionResult.success({ summary: `saw ${ctx.work.beads_work_id}` }));

const run = await furnace.run({ formula: "feature-development", executor: "coder" }); // StartedRun
run.record.state; // "completed"
```

- `furnace.executor(name, callback, options?)` is `ExecutorApp.executor` on the one app the
  client owns (`furnace.app`): the callback is returned unchanged, `options.durability` is
  its durability declaration, and the same function runs under the one-shot host, the
  resident host and here without a signature change. `furnace.run({ formula, executor,
  vars?, persistent?, env? })` starts the Run with that registration as its executor and
  resolves to `runs.start`'s `StartedRun`; an `executor` the client did not register is an
  `UnknownExecutorError` before anything is written or invoked.
- The channel: for the Run's duration the client serves its callbacks over a Unix socket
  with the resident host's `ResidentSession` (`src/resident_session.ts`, so nothing here
  redefines `process.stdout`), and writes a configuration file for the Run (`[execution]
  executor` and one `[executors.<name>]` under `driver = "extension"` naming this `node`,
  `dist/src/bridge.js` and the socket) that it passes as `--config`; Furnace spawns the
  bridge per Attempt as it spawns any resident host, and the bridge relays stdin/stdout to
  the socket, so the protocol on the channel is `furnace.executor.v1` and the extension
  driver is unchanged. The client's own `config` file, when given, is copied first (it must
  not define `[execution]` or that executor's table). Socket and file are removed before
  `run` resolves.

## What the types promise

- DTO payloads (`response.data`, `run.record`) keep the wire's snake_case, as the documented
  envelopes (`crates/furnace-protocol`) spell them. The envelope wrapper (`Response`)
  exposes `protocolVersion`, `requestId` and `kind`; a `FurnaceCommandError` exposes
  `protocolVersion`, `requestId` and `responseKind` (the error envelope's own `kind`).
- `protocol_version` is read first and alone. A version outside
  `SUPPORTED_PROTOCOL_VERSIONS` is an `IncompatibleProtocolError` carrying the observed
  version and the supported range, and no field of the payload.
- A Furnace error envelope is a `FurnaceCommandError` with its `code` (a `code` outside
  `ERROR_CODES` is refused as `MalformedOutputError`). The client's own observations —
  `MalformedOutputError`, `ProcessFailedError`, `UnexpectedResponseKindError`,
  `StreamTruncatedError`, `StreamOrderError`, `BinaryUnavailableError`, `RequestTimeoutError` — each
  carry what was
  actually observed (bytes and exit status where there were any) and never a fabricated
  verdict. These, and the decode and registration errors, are `FurnaceError` subclasses
  with a `kind` discriminant. Some failures are not: `ContractUnavailableError` (an install
  with no shipped contract), the host's `DefinitionLoadError`, the plain `Error` from iterating
  one `EventStream` twice, and the `TypeError` `runs.start` throws on a success envelope
  whose `data` is `null`.
- `run.events()` yields each JSONL line as it arrives. At protocol 1 the stream is
  `logs --follow`: the `attempt.output` events of one Attempt (the Run's newest, or the one
  `{ work }` / `{ attempt }` names), ending when the CLI exits 0 after that Attempt
  finishes, with `stream.terminalEvent` `null`. The terminal Run kinds
  (`run.completed`/`run.stopped`/`run.failed`) are part of the contract, and iteration
  would also complete on one, but this binary's follow stream does not emit them. Any other
  end is `StreamTruncatedError`, including a refused follow, whose error envelope is then
  only in `.stderr`.
- Additive unknown fields within a compatible protocol version are ignored (FRN-PRO-002).
  The event reader requires `type` to be a string and does not hold it to `EVENT_KINDS`
  (`FurnaceEvent.type` is `EventKind | (string & {})`), so an event of a kind that roster
  does not list is still yielded.
- Streams follow the CLI's rule: a success document is read from stdout, and when stdout
  is empty the one error envelope the CLI writes to stderr is read from there. A stdout
  document is always the truth; stderr prose beside it is diagnostics, exposed as
  `response.stderr`. A success document with a nonzero exit is returned, not thrown
  (`response.exit`).
- Every buffer the transport holds is bounded (byte limits on `SpawnRequest`): `runCaptured`
  keeps at most `captureLimitBytes` (default 64 MiB) of each of stdout and stderr — a prefix
  and a suffix — and reports an over-limit stream as a `Truncation` (bytes seen, kept and
  dropped) on `Captured.truncated`; a `LineStream` keeps at most `stderrLimitBytes` (default
  1 MiB) of stderr the same way (`LineStream.truncated`); one stdout frame holds at most
  `frameLimitBytes` (default 16 MiB; a longer one fails the stream as a `MalformedOutputError`
  framing defect), and unread lines queue only up to `maxQueuedBytes` (default 16 MiB), past
  which the pipe is paused until the consumer drains it (backpressure, nothing dropped).
  `test/transport_buffers_are_bounded.test.ts` checks the exact metadata at a 4 KiB limit,
  and `test/transport_bounds.test.ts` drives output about 130x to 1000x past each bound,
  each case beside a control under the default bound.

## Developing

Node 22 or newer (`engines`), with type stripping on by default
(`node -p process.features.typescript` prints `strip`): the SDK loads the generated
contract's TypeScript source with `require()`, and a Node that does not strip types fails
at the first decode. Dependencies are dev-only (`typescript`, `@types/node`), pinned, with
`package-lock.json` committed.

```sh
npm ci
npm test
```

`npm test` first removes `dist/` (`npm run clean`), then compiles `src/` and `test/` into it
and runs the suite with `node --test`, so a compiled test whose source has been removed or
reverted is never run (`npm run build` alone only writes outputs and never deletes one whose
source is gone; the fixture
`tests/shell/integration/sdk_typescript_npm_test_never_runs_an_orphan_compiled_test.sh`
holds this paragraph and the `test` script to each other). Among its files:

- `test/battery.test.ts` — the shared contract battery: one test per case id in
  `tests/fake-furnace/cases.json`, replayed against the fake `furnace`, plus a final check
  that the executed-case ledger equals the manifest (ten cases).
- `test/error_code_denominator.test.ts` — every `ErrorCode` instantiated through the fake,
  each arriving typed, with the list held to `ErrorCode::ALL` in the protocol crate.
- `test/argv.test.ts` — the argv the client hands the binary.
- `test/lifecycle_verbs.test.ts` — the Run lifecycle verbs (`runs.adopt/resume/pause/stop`,
  `attempts.list/inspect/stop`, `work.retry`, `logs.read`) read back from a recording binary,
  and the per-request timeout against a stalled fake: typed, inside the bound, child reaped.
- `test/real_binary.test.ts` — the real-binary journey (`target/debug/furnace`, or
  `FURNACE_TEST_BIN`); skipped, and reported as skipped, when no binary is present.
- `test/embedded_run.test.ts` — Generation 3: a callback registered on the client runs in the
  test process for one Run driven through the real binary and the fake `bd` (`D308`); the
  journey leg is skipped, and reported as skipped, when no binary is present.
- `test/success_paths.test.ts` — `doctor()`, `runs.status()` and `runs.list()` decoded from
  the fake and from the real binary, each payload type pinned by a key table; the real leg is
  skipped, and reported as skipped, when no binary is present.
- `test/attention_plan_decodes.test.ts` — the `details.attention.plan` member of an
  `unsafe_recovery` refusal decoded as the typed view (`AttentionDetails`, `AttentionPlan`,
  `AttentionPlanStep`, ...), each view held key for key to its `pub struct` in the protocol crate.
- `test/event_stream_protocol_gate.test.ts` — the per-line protocol gate of `run.events()`
  and the `StreamOrderError` on a `sequence` that does not increase.
- `test/contract_packaged_copy.test.ts` — the shipped copy of the generated contract
  (`contract/`, the build product of `scripts/sync_sdk_contract.py --write`): a copy of the
  built package outside a checkout loads it from its own directory, the manifest's model
  digest equals the loaded module's, a manifest naming another model than its module
  is a `ContractUnavailableError`, and the copy carries the conformance corpus byte for byte.
- `test/conformance_registry_resolution.test.ts` — `run-battery` with no `--registry`: from
  a copy outside a checkout it reads the shipped `contract/registry/`, neither candidate is
  a refusal naming both paths, `--registry` wins, the obligations beside the copy are
  recorded and stay optional, and inside a checkout-shaped tree the checked-in registry is
  the fallback while the shipped copy wins when both exist (by `inventory.registry`); every
  case passes from the copy, `BEH-004` over the shipped exception battery, which wins over the
  test tree's compiled definition the same way (by the cases the driven battery names), and
  with neither `BEH-004` fails naming both paths.
- the executor half: `test/executor_app.test.ts`, `test/models.test.ts`,
  `test/host.test.ts`, `test/resident_host.test.ts`, `test/async_is_primary.test.ts`,
  `test/promise_callbacks_are_awaited.test.ts`, `test/callback_signature_is_host_neutral.test.ts`,
  `test/two_apps_do_not_share_a_registry.test.ts`, `test/streaming.test.ts` (callback
  output streamed through the host before its terminal result) and
  `test/callback_events.test.ts` (`ctx.events` progress and notice under both hosts);
  `test/durability_declaration.test.ts` and `test/resident_durability.test.ts` (the durability
  declaration's projection of the model's `DurabilityProfile`, refused at registration when it
  breaks the registry's profile rules, advertised by the resident host, and a false claim's
  durable operation answered in its own vocabulary without entering the callback:
  `unsupported`, or an `ExecutorProtocolError` for `resolve_execution`);
  `test/durable_callbacks.test.ts` and `test/resident_durable_callbacks.test.ts` (the continuity
  provider bound beside the declaration: `BOUND_OPERATIONS`, the typed `CheckpointRequest` /
  `CheckpointOutcome`, `RestoreRequest` / `RestoreOutcome` and `ResolveRequest` /
  `ResolveOutcome`, the registration refusals, and the resident host's `checkpoint` dispatch
  with the execution identity and the active receipt — every malformed case refused before the
  method, a checkpoint after the terminal answered `already_terminal` from the host's own maps —
  its `resolve_execution` dispatch (the provider's `found`, cross-checked against the host's
  record, on a fresh host too) and its `restore` dispatch (a new incarnation under a new receipt,
  deduplicated on `restore_request_id`, refused while an incarnation runs, the model's closed
  words otherwise); `test/resident_support.ts` is their host plumbing);
  `test/durable_vocabularies_are_the_models.test.ts` (every durable vocabulary the SDK reads —
  `CheckpointStatus`, the `DurabilityProfile` members, the `CheckpointRef` wire names — held
  both ways to the model text, and no module under `src/` restating one) and
  `test/durable_compatibility_cases_are_counted_apart.test.ts` (an unknown additive member
  tolerated, an unknown durable status word refused, the two families counted apart over the
  registry's fixtures);
  `test/resident_admission.test.ts` (admission deduplicated by `execution_id` for an executor
  declaring `deduplicate_admission`, with the non-deduplicating control host under
  `test/hosts/` that the same assertion must fail against); the
  client's protocol gate and transport boundary in `test/protocol_version_predicate.test.ts`
  and `test/transport_privacy.test.ts`; the transport's memory bounds in
  `test/transport_buffers_are_bounded.test.ts` and `test/transport_bounds.test.ts` (each
  bound driven past by a child, beside a control that stays under it); and
  `test/vocabulary_parity.test.ts`, which holds `ERROR_CODES`, `RESPONSE_KINDS` and
  `EVENT_KINDS` to the generated skill reference's tables;
  and `test/client_surface_parity.test.ts`, which holds the client's public surface to the
  generated reference's `Client operations` table (every `mirrored` row resolves to a public
  method, every public method sits in exactly one row, both clients mirror one command set).
- `test/resident_host_names_on_the_object_prototype_are_unknown_operations.test.ts` — an `op`
  that is only a name inherited from `Object.prototype` (`toString`, `constructor`,
  `__proto__`, ...) is refused as an unknown operation naming the word, before and after
  `hello`, and the host serves on; `DURABLE_OPERATIONS` (`src/durability.ts`) holds, reads
  and claims no inherited name, `expectedShapes` refuses each, and the table is still the
  registry's gates in their order. The twin of
  `sdk/python/tests/test_resident_host_names_on_the_object_prototype_are_unknown_operations.py`.
- `test/resident_host_answers_every_json_type_in_op_and_cancel_ids.test.ts` — an `op` that is
  a JSON array or object (`[]`, `["x"]`, `{}`, `{"a": 1}`, `[[]]`, `["checkpoint"]`) is
  refused `ExecutorProtocolError` with the value echoed as `op` and the `request_id` echoed,
  and a Cancel whose `execution_id` is one of those values answers `unknown_execution`, as
  the scalar controls `null`, `1` and `""` do; after each the next Observe is answered and
  the host exits 0 at end of input. The twin of arms b and c of
  `sdk/python/tests/test_resident_host_answers_every_json_type_in_op_and_cancel_ids_and_keeps_serving.py`.
- `test/resident_host_answers_a_request_nested_too_deeply.test.ts` — a request line
  `JSON.parse` takes but `JSON.stringify` cannot echo is answered and the host serves on:
  an `op` 100,000 deep is refused `ExecutorProtocolError` with `op` null and the `request_id`
  echoed; an `execute` whose `request_id` is 100,000 deep is refused with `request_id` null
  before it is dispatched (never acknowledged, never admitted, the callback never entered),
  and a later `execute` is acknowledged and run; every other request value a refusal renders
  (a first `hello`'s offered versions, the `protocol_version` stamp, `execute`'s
  `execution_id` and `executor`), 100,000 deep, is refused with the `request_id` echoed and
  the value rendered as the fixed phrase. Each deep line is followed by an answered Observe
  and the host exits 0, beside the controls (an `op` 3,000 deep refused with the value echoed
  as `op`; a top-level array and an Observe `input` 100,000 deep answered). The twin of
  `sdk/python/tests/test_resident_host_answers_a_request_nested_too_deeply_and_keeps_serving.py`,
  which sweeps depths 950 to 1000 instead, across where that interpreter's recursion limit
  stops its decoder and encoder.
- `test/resident_host_answers_a_durable_request_nested_too_deeply.test.ts` — a durable
  request whose `execution_id` is nested too deeply to render is answered and the host serves
  on. The durable gate (`src/resident_session.ts`) runs before the generated input validator,
  so when the request names no execution the host accepted, every served executor decides and
  they disagree on the operation's gating member, a `checkpoint`, a `restore`, a
  `resolve_execution` and a `replay_events` whose `execution_id` is 100,000 arrays deep, and
  a `checkpoint` whose `execution_id` is 100,000 objects deep, are each refused
  `ExecutorProtocolError` naming the disagreement, with the `request_id` echoed and the id
  rendered as the fixed phrase (an id 3 deep is rendered as it was sent). Each deep line is
  followed by an answered Observe and the host exits 0, beside the controls (one deciding
  executor's generated input validator refuses an `execution_id`, a `receipt`, a `checkpoint`
  or a `restore_request_id` 100,000 deep by type name, with the `request_id` echoed; a
  `restore` whose checkpoint's `opaque_reference`, or whose context carries a member no shape
  names, 100,000 deep enters the provider and is answered its word, and a `checkpoint` and a
  `resolve_execution` carrying such a member are answered, none of those values rendered). It
  has no Python twin: the Python host already answers those lines (its gate renders the id it
  decoded, and a line nested past its recursion limit is refused at decode).
- `test/a_failing_resident_test_never_leaves_its_host_running.test.ts` — `node --test` over
  `test/hosts/fails_after_hello.ts` (deliberately no `*.test` file, so the suite never runs
  it on its own), whose one test fails an assertion after a successful `hello` read, closes
  inside its deadline with a non-zero exit, names that test `not ok`, prints its summary and
  leaves no process of its group running: `test/resident_support.ts` (and each private copy
  of its `Resident`) kills every host a file's tests started once those tests are done, as
  the Python fixture teardown in `sdk/python/tests/test_resident_host.py` does.
- `test/a_failing_host_client_test_never_leaves_its_host_running.test.ts` — the host-client
  twin of the row above, in two arms. (a) `node --test` over
  `test/hosts/client_fails_after_hello.ts` (deliberately no `*.test` file, so the suite never
  runs it on its own), whose one test starts the resident host on an `ExecutorHostClient`
  through `test/host_client_support.ts`'s `spawnHost`, reads the `hello` reply and fails an
  assertion with that host still running, closes inside its deadline with a non-zero exit,
  names that test `not ok` for its deliberate reason, prints its summary and leaves no
  process of its group running. (b) No file under `test/` but `test/host_client_support.ts`
  starts an `ExecutorHostClient` host through the class's static `spawn`, with the support
  module's own call as the control the same pattern must find. `spawnHost` records every
  client it starts, and the module-level `after()` hook of `test/host_client_support.ts`
  closes each recorded client once the importing file's tests are done, a failed assertion
  included; the three host tests of `test/host_client_cases.ts` (registered by
  `test/resident_host.test.ts`) start theirs through it.
- further suites, one file per surface: `test/attempt_ceiling_override.test.ts`,
  `test/conformance_resident_cancel.test.ts`, `test/conformance_result_controls.test.ts` (the
  status control of the `RESULT-STATUS-POS-*` rows against lying decoders),
  `test/conformance_run_battery_flags.test.ts`,
  `test/conformance_terminal_classification.test.ts`, `test/event_stream_abandonment.test.ts`,
  `test/execution_receipt_durability.test.ts`, `test/executor_dto_rows_match_dto_rs.test.ts`,
  `test/plan_report_and_eligibility_record.test.ts`,
  `test/query_supervision_and_host_dtos.test.ts` (these three share their Rust readers,
  `test/rust_readers.ts`),
  `test/read_verbs.test.ts`, `test/resident_cancel_continuity.test.ts`,
  `test/resident_host_identity.test.ts`, `test/stream_close_escalates_to_kill.test.ts`,
  `test/stream_defects_are_classified.test.ts`,
  `test/transport_runs_under_type_stripping.test.ts`, `test/work_inspect_shape.test.ts`.

`scripts/test.sh sdk-typescript` runs this suite as a mandatory tier
(`tests/shell/sdk-typescript/the_typescript_client_suite_passes_under_node_test.sh`); running
it from this directory is the same suite. The tier compiles with the pinned `typescript`
under `node_modules` (installing it with `npm ci` when it is absent) into scratch, and
reports PEND when there is no Node at the `engines` floor, or when the compiler is absent
and there is no `npm` to install it with or its `npm ci` fails (for example, the registry
is unreachable).
