# @hyperunix/sdk

An asynchronous TypeScript client for HyperUnix: typed read-only workspace operations, a lower-level raw argv
escape hatch, typed canonical values and runtime identifiers, and named queries as typed callables -- all over the
authoritative `hx` runtime through its machine protocol (HXS). Experimental, additive; the runtime stays the
semantic and schema authority. The SDK spawns `hx` with an argv array (never a shell), decodes its machine frames
and returns rows, coverage and diagnostics exactly as the runtime emitted them. Requires Node.js 22.18 or later and
an installed `hx` executable; this package never downloads a binary.

```ts
import { HyperUnix } from "@hyperunix/sdk";

const hx = await HyperUnix.open({ workspace: "/work/project", binary: "/usr/local/bin/hx" });
try {
  const shown = await hx.show("src/file.ml");
  const found = await hx.find({ kind: "hx.fs/regular-file", root: "." });
  const raw = await hx.raw.run(["git", "history", "src/file.ml"]);
} finally {
  await hx.close();
}
```

## Binary selection and compatibility

`HyperUnix.open` (and `new HyperUnix(options)`) chooses the constructor `binary`, then `config.binary`, then
`HYPERUNIX_HX` (legacy `HYPERUNIX_BINARY` fallback), then an executable `hx` on `PATH`; `runtime.binaryOrigin`
(`constructor`, `sdk-config`, `environment`, `path`; `runtime.binarySource` is the same value) identifies the winning
source. Explicit selection never falls back. Before the first operation the client runs `hx --version` and
`hx --help --hxs` once and records the binary SHA-256, the separate SDK and runtime versions, the implemented verbs
and the HXS protocol. The finite protocol range is HXS 1.0 only; `show`, `find`, `run`, `query show` and
`query list` are required verbs (`COMPATIBILITY.requiredVerbs`). Runtime semantic-version differences alone do not
establish incompatibility. Missing or incompatible runtimes fail with typed errors before any verb is spawned:
`BinaryNotFoundError` (`SDK_BINARY_NOT_FOUND`, carrying the selection origin and path) and `IncompatibleRuntimeError`
(`SDK_INCOMPATIBLE_RUNTIME`, carrying `detectedHxs`, `detectedVersion`, the required protocol and the missing
capabilities; `ProtocolCompatibilityError` is its retained subclass name). Negotiation probes have a sixty-second
deadline (`limits.probeTimeoutMs`; the real hx answers in milliseconds, the bound exists for a starved host). The exported `COMPATIBILITY` declaration states the SDK version, the minimum and
tested hx versions, the supported HXS versions and the required verbs.

`client.runtime` is both the negotiation and its facts: `await client.runtime()` negotiates (once) and returns the
`RuntimeInfo`; after `HyperUnix.open({ workspace, ... })` resolves, the same object carries `binaryPath`,
`binarySha256`, `version`, `hxsVersion`, `protocol`, `verbs`, `capabilities` and `sdkVersion` as readable fields.

## Typed reads and the raw escape hatch

Typed reads encode argv in the order shared with the Python SDK (`encodeArgv`: verb tokens, options,
`--workspace ROOT`, `--authorize k=v`, `--hxs`, `--`, operands); `find` runs the native strict coverage policy by
default (`bestEffort: true` adds `--best-effort`) and a complete HXS stream with exit 3 (coverage incomplete) is
returned with its rows, coverage frames and exit code rather than collapsed. A `ReadResult` carries the validated
frames, the native claim bodies (`rows`) and coverage, raw stdout/stderr text, exit code, signal, structured
diagnostics, stderr prose, stream summaries and transport timing. `hx.raw(argv)` / `hx.raw.run(argv, options)` is
the lower-level escape hatch (also `workspace.raw(argv)`): it keeps the caller's argv verbatim and adds `--workspace`
and `--hxs` only when absent, before any `--` delimiter (every following token stays literal data, even
`--workspace`, `--hxs` or `--human`); it never promises a semantic certificate for a human-only verb, and it refuses
shell strings and human-mode output options (`SdkUsageError`, a `TypeError`). Every execution uses one asynchronous
`spawn` with `shell: false` in an owned process group; no production path references a synchronous child-process API.

Named queries (`workspace.namedQuery(name)`, `namedQueryFromCapture`, `listNamedQueries`; `hx.*` typed carriers)
load a saved query as a typed callable and execute the exact captured definition; see the named-query section below.

## Protocol decoding and safety limits

Reads validate HXS framing, sequence, observation batches and the required terminal frame. Provisional SDK safety
defaults (`DEFAULT_LIMITS`): 1,048,576 bytes per frame, nesting depth 64, 8 MiB total stdout, 65,536 retained stderr
bytes, 256 diagnostics, a 600 s operation deadline and a 100 ms SIGTERM-to-SIGKILL grace. Frame/depth/total limits are
configurable independently of native query budgets and never rewrite query cost. Malformed or oversized input
produces `ProtocolError` with code `SDK_PROTOCOL_ERROR` or `SDK_PROTOCOL_LIMIT` (`ProtocolLimitError`), and non-frame
prose on a semantic read produces `SDK_PROTOCOL_UNSTRUCTURED_STDOUT` (`UnstructuredStdoutError`), never a fabricated
empty success; raw results keep such bytes verbatim (`stdoutUnstructured`, retained up to 65,536 bytes, with
`stdoutUnstructuredBytesTotal` counting every delivered byte). The named-query executor decodes after EOF with the
frame parser's codes (`SDK_PROTOCOL_PROSE`, `SDK_PROTOCOL_MALFORMED`, `SDK_PROTOCOL_UNSUPPORTED`, `SDK_PROTOCOL_TORN`).
Refusal, cancellation (`dispose`) and the deadline terminate the owned POSIX process group, escalating after the
grace; Windows currently uses direct-child termination and has not been validated for process-tree cleanup.

Structured diagnostics come only from stderr JSON lines and HXS `diagnostic` frames (`origin` `stderr` or `hxs`),
never prose; diagnostic fields redact `sensitiveValues` plus credential-like environment values. Process-failure
exceptions (`ProcessFailureError`) omit raw byte channels to avoid accidental logging. Explicit raw results remain
caller-owned and may contain secrets; do not log them. The SDK emits no default telemetry or row logs.

The SDK performs no workspace initialization or metadata writes: constructing a client or a workspace performs no
process I/O and resolves nothing; the asynchronous open probes only version and capabilities; native configuration
merging and authorization remain runtime-owned and no constructor default emits `--authorize`. `dispose()` initiates
cancellation synchronously; `close()` awaits owned pending processes. Native `hx.fs/file` refuses as an unknown kind
(HX-TYPE-UNKNOWN-KIND, exit 2); the registered filesystem kind is `hx.fs/regular-file`, and the tests carry the literal
clause as a refusal-parity case (acceptance correction tracked by hu-ft6wz).

## Typed canonical values

`Int`, `Float`, `Duration`, `Timestamp`, `Digest`, `Identifier`, `Locator`, `HxSymbol`, `HxRecord`, `HxSet` and the
`encode` / `decode` / `encodeCanonical` / `decodeCanonical` codecs preserve HX values without loss (HXCanonical/1:
tagged bigints, int64 durations, byte payloads, order-independent sets). Lossy host conversions raise `SdkUsageError`.

## Read-only provider and schema discovery

```ts
const client = new HyperUnix({ binary: "/usr/local/bin/hx" });
const workspace = client.workspace("/work/project");
const providers = await workspace.providers.list();
const detail = await workspace.providers.inspect("hx.fs");
const bundles = await workspace.schemas.list();
const alias = await workspace.schemas.show("hx.lang/unit-dependency");
const realizers = await workspace.schemas.providers("hx.fs/regular-file");
await client.close();
```

These facets call only native `observer list/inspect` and `schema list/show/providers --hxs`.
`DiscoveryResult.records` contains typed immutable projections; `bodies` and `toWire()` retain complete
native metadata, including optional fields, typed digests, large integers and full schema bundles.
Provider identity, manifest and capabilities remain `undefined` for bare candidates when the runtime
provides none. Cost values are `bigint` declarations, not measurements. `isComplete` describes a
successful terminated inventory only, never graph absence, applicability or trust. Partial exits,
Unknown metadata and structured runtime refusals remain distinguishable; malformed or torn streams
throw typed protocol errors. Results retain runtime binary identity, diagnostics, argv, exit and timing.
Discovery performs no provider probe, direct session setup or trust write. Normal query routing stays
with HyperUnix; the optional advanced HXSP session API is not selected. A local discovery fixture does
not certify live HXSP integration.

`forge run test-introspection --path sdk/typescript` runs all five implemented tiers. Individual
replays use `forge run test-shell|test-client|test-integration|test-unit|test-failure --path sdk/typescript
-- --slice introspection`. The shell and client tiers install the packed npm artifact into a foreign
consumer, compare to independent native output, arm execution markers and snapshot trust files.

## Named queries as typed callables

```ts
import { HyperUnix, hx } from "@hyperunix/sdk";

const workspace = HyperUnix.open("/path/to/workspace");
const entries = await workspace.namedQuery("entries");      // hx query show entries --hxs, frozen
entries.parameters;                                         // declared names, types, persisted typed defaults
entries.digest;                                             // the runtime's semantic digest
const result = await entries.run({ root: "src", depth: 2n }, { bestEffort: true });
result.rows; result.coverage; result.diagnostics; result.exitCode;
```

A loaded handle executes the definition it captured (`hx run NAME --query <captured>`): saving a different
body under the same name afterwards changes nothing the handle does, and a tampered capture is refused by
the runtime (`HX-QUERY-DEFINITION-DIGEST-MISMATCH`) without evaluation. `handle.toJSON().captured`
re-hydrates through `workspace.namedQueryFromCapture(text)` in another process.

Arguments bind by declared name and type, one `--name:canonical=<json>` token each (HXCanonical/1):
`boolean`, `bigint`, `number`, `string`, `Uint8Array` bind to `bool`, `int`, `float`, `string`, `bytes`;
`hx.timestamp`, `hx.duration`, `hx.digest`, `hx.identifier`, `hx.locator`, `hx.symbol` spell the rest;
element (kind) parameters take locator text or `hx.locator`. Nothing is coerced -- a `number` is never an
`int`, a string never `bytes`, `true` never `1` -- and values the runtime has no spelling for (NaN,
infinities, negative zero, lone surrogates, durations outside int64) are refused before any process starts
(`SDK_ARGUMENT_UNREPRESENTABLE`). Undeclared, duplicate or missing arguments are refused locally against
the loaded metadata; `{ validate: false }` lets the runtime judge instead, and its refusal
(`HX-TYPE-PREDICATE-MISMATCH`, `HX-CLI-USAGE-ERROR`) comes back inside the result, never as a substituted
query. `decodeCanonicalScalar` decodes one named-query parameter image; `decodeCanonical` is the general codec.

## Package

ESM-first; CommonJS compatibility is not promised in this provisional first package. The public entry is the
package root; the lower-level transport (`runHx`, `encodeArgv`) lives at `@hyperunix/sdk/raw` and the frame decoder
(`FrameDecoder`) at `@hyperunix/sdk/protocol`; the root exports neither. The package has no runtime dependencies.
TypeScript supplies declaration generation/checking; `@types/node` supplies Node platform types, both development-only
and exactly pinned (package-lock.json). The shipped declarations spell no Node-only type (`NodeJS.*`, `Buffer`): the
public environment type is `ProcessEnv` (`Readonly<Record<string, string | undefined>>`, the shape of `process.env`),
`ProcessResult.signal` is a signal name string or null, and `FrameDecoder` takes and keeps `Uint8Array` (a `Buffer` is
one), so a consumer that installs the package alone typechecks against them with a bare
`tsc --noEmit --module nodenext --moduleResolution nodenext`. Declaration maps and source maps are emitted provisionally. Verified runtime:
Node 22.23.3 on Linux with the locally compiled hx 0.1.0 (each census line records the exact Node version and hx
sha256 of its run); other Node versions remain untested, and Node below 22.18 cannot run the test tiers (native type
stripping). Registry publication and name ownership are not implied by local tarball tests.

## Development and verification

`node tools/provision.mjs` (also `forge run install`) installs the pinned devDependencies from package-lock.json;
`node tools/build.mjs` (`npm run build`) compiles `src/` to `dist/` with declarations, declaration maps and source
maps, rewriting relative `.ts` specifiers to `.js`; `node tools/check.mjs` (`forge run check`) runs the strict
`tsc --noEmit` over `src/` and the test tiers; `node tools/lint.mjs` (`forge run lint`) runs `tools/no-shell-gate.sh`
first (exit 1 on any `shell: true`, `child_process.exec(`, `execSync(`, `execFileSync(`, `spawnSync(` or prose-count
regex under `src/`, and on any `node:child_process` import other than `{ spawn }`; `RegExp.prototype.exec` in the value
parsers is not a process API) and then the SDK's hard rules over `src/`, `test/` and `tools/`. The hx under test is
`HX_SDK_HX_BIN` (or `--hx`) or the fresh build at `<repo>/_build/install/default/bin/hx`; a bare PATH `hx` never
substitutes for it.

`forge build --path sdk/typescript` runs the package gate, whose nine steps equal the declared tiers (`lint`, `check`,
`test-unit`, `test-conformance`, `test-failure`, `test-integration`, `test-client`, `test-shell`, `package`) exactly as
`sdk/python/forge.toml` declares them; `package` compiles and writes the npm tarball to `pack/`, outside the `dist/`
outDir. `tools/run-tests.mjs` is the single runner, mirroring `sdk/python/tools/run_tests.py`:
`node tools/run-tests.mjs --tier <tier> [--slice bootstrap|named|values]` (through Forge:
`forge run test-shell -- --slice bootstrap`), `--all-implemented` for every tier of every slice, `--package pack`
for the tarball. Every tier prints one JSON census line per slice, last, with `tier`, `slice`, `status`, `cases`,
`passed`, `failed`, the `requirements` its executed cases carried (the `[HXSDK-...]` prefixes of their names),
`hx_sha256`, `hx_version`, `node`, the subject identity and per-case results. Exit 0 PASS; exit 1 RED (a measured
behavioral failure); exit 2 HARNESS (setup could not be established: hx missing or not runnable, compiler missing,
package build or foreign install failed, empty selection; the census line carries `status: "HARNESS"` and a
`reason`); exit 4 ABSENT (the public API is not exported; never PASS). Forge captures task output: `forge run -v`
streams the census, a plain `forge run` prints only its own line, and a HARNESS exit 2 from the runner surfaces as
Forge exit 1 `FORGE_COMMAND_FAILED` with the census line retained in the `--json` diagnostics (tracked by hu-ft6wz).

Bootstrap slice tiers: the unit tier runs the cross-language argv parity program (`test/unit/argv-parity.test.ts`,
`PARITY OK` only when every encoded argv equals Python's `encode_argv` token for token), the frame decoder and the
structural no-shell check; the conformance tier runs the same read over the CLI backend and a fixture-replay backend,
the shared `sdk/conformance/evidence` corpus through the decoder and the pinned HXS 1.0 reference; the failure tier
runs the wire-byte battery (`test/client/safety.mjs`); the integration tier runs the native-parity journey from
source (`test/client/journey.mjs`: `show`/strict `find` parity with direct `hx ... --hxs` including exit codes and
node-claim counts, markerless roots A/B with caller cwd B, the no-root case through the `./raw` entry, metacharacter
operands, binary precedence, missing-binary origins, compatibility refusals through `sdk/python/test/fakes/fake_hx.py`
wrappers, the exact argv transcript, and `hx config explain` parity for the default, user, workspace, environment
and cli layers including restrict-only rejections and one-call `--authorize`); the client tier runs the same journey
as an external consumer program installed from the packed tarball in a foreign cwd plus the strict isolated
declaration consumer of the root, `./raw` and `./protocol` entries; the shell tier (`test/shell/bootstrap.sh`) packs
the distribution, installs the tarball into a foreign project, records native `show`/`find`/no-root references with
the shell itself, runs `test/shell/consumer.mjs` from cwd B under an isolated `HOME`/`XDG_CONFIG_HOME`, cross-checks
the consumer's observed exits, node-claim rows and row bodies against the shell's own references, and verifies
byte-identical workspace and HOME snapshots. The profile layer has no caller-settable surface in the pinned runtime
(`hx config explain` consults it as `profile (in-memory)`, never present): the config cases assert its position in
the consulted layer order and its origin row, and no case claims a value it supplied.
